#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>

using namespace sf;

void Update(int& keyTime, RectangleShape& square, RenderWindow& window);
void Draw(RenderWindow& window, RectangleShape& square);

int main() {
	int keyTime = 8;
	RenderWindow window(VideoMode({ 640,480 }), "A window is opening");
	window.setFramerateLimit(60);

	RectangleShape square(Vector2f(100.f, 100.f));
	square.setFillColor(Color::Red);
	square.setPosition(Vector2f(window.getSize().x / 2, window.getSize().y / 2));

	while (window.isOpen()) // check the window still open    // ��Fopen window��method �o�ӬOSFML 3.0��
	{
		while (const std::optional event = window.pollEvent())
		{
			if (event->is<sf::Event::Closed>()) {
				window.close();
			}
			else if (const auto* keyPressed = event->getIf<sf::Event::KeyPressed>())
			{
				if (keyPressed->scancode == sf::Keyboard::Scancode::Escape)
					window.close();
			}
		}

		Update(keyTime, square, window);
		Draw(window, square);

	}

	return 0;

}


void Update(int& keyTime, RectangleShape& square, RenderWindow& window) {
	if (keyTime < 8) {
		keyTime++;
	}
	if (Keyboard::isKeyPressed(Keyboard::Key::A) && square.getPosition().x > 0) { //�p�G�A�n��mouse �n�� Key::A, B, C ,D,

		square.move(Vector2f(-5.f, 0.f));
		keyTime = 0;

	}
	if (Keyboard::isKeyPressed(Keyboard::Key::D) && square.getPosition().x + square.getSize().x < window.getSize().x) {

		square.move(Vector2f(5.f, 0.f));
		keyTime = 0;

	}
	if (Keyboard::isKeyPressed(Keyboard::Key::W) && square.getPosition().y > 0) {

		square.move(Vector2f(0.f, -5.f));
		keyTime = 0;

	}
	if (Keyboard::isKeyPressed(Keyboard::Key::S) && square.getPosition().y + square.getSize().y < window.getSize().y) {

		square.move(Vector2f(0.f, 5.f));
		keyTime = 0;

	}
	if (Mouse::isButtonPressed(Mouse::Button::Left)) { //�p�G�A�n��mouse �n�� Button::Left

		square.setFillColor(Color::Blue);

	}
	else {
		square.setFillColor(Color::Red);
	}

}
void Draw(RenderWindow& window, RectangleShape& square) {

	window.clear(Color::Black);
	window.draw(square);
	window.display();
}


